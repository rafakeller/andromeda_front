import { IPalette } from "./IColor";

const palette: IPalette = {
  primary: {
    1: "#120F26",
    2: "#120F26",
    3: "#120F26",
    4: "#120F26",
    5: "#120F26",
    6: "",
    7: "",
  },
};
